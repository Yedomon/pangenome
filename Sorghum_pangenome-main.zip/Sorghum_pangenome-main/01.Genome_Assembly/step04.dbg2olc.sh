/ifs4/BC_PUB/biosoft/pipeline/DNA/DNA_Denovo/PacBio/DBG2OLC/Programs/DBG2OLC_Linux k 17 Contigs ./S353.Sorghum_contig.fa LD1 0 KmerCovTh 3 MinOverlap 20  AdaptiveTh 0.005 MinLen 50 RemoveChimera 1  f  ./S353.proovread.trimmed.NoN.fa 

